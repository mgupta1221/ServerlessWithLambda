const express = require('express');
const http = require('serverless-http');

const app = express();
app.get('/apiRouteWithExpressRoute', (req, res) => {
    console.log('base route');

    res.json({
        message: 'Message from Base route'
    })
})

app.get('/apiRouteWithExpressRoute/foobar', (req, res) => {
    console.log('foobar route');
    res.json({
        message: 'Message from fooBar route'
    })
})

module.exports.handler = http(app);