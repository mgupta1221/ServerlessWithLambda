module.exports.handler = (evt, ctx, done) => {
    done(null, 'Killer');
    return evt;
}
